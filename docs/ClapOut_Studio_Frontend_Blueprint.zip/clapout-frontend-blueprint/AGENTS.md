# Codex Project Agent - ClapOut Studio Frontend

You are implementing the ClapOut Studio frontend with Angular, PrimeNG, and Tailwind CSS.

## Required reading order

Before making changes, read:

1. `README.md`
2. `docs/01-product-mvp.md`
3. `docs/02-frontend-architecture.md`
4. `docs/03-design-system.md`
5. `docs/04-routes-and-permissions.md`
6. `docs/05-quality-and-delivery.md`
7. The current `phases/NN-*.md` file
8. The preceding phase handoff, if present

Use `Clapout.pdf` as the visual reference when it is available in the repository. The PDF is a baseline; fix obvious copy, accessibility, consistency, and responsiveness issues rather than reproducing defects.

## Operating rules

- Work only on the current phase unless the user explicitly expands scope.
- Inspect the repository and existing conventions before proposing or editing.
- Preserve unrelated user changes.
- Use Angular standalone APIs, lazy feature routes, typed Reactive Forms, signals for local UI state, and repository adapters for server data.
- Keep mock data out of components.
- Do not add NgRx, another UI kit, or a second styling framework without an architectural reason and explicit approval.
- Prefer PrimeNG for behavioral primitives and Tailwind for composition.
- Use shared tokens; do not scatter raw brand colors through templates.
- Enforce permissions in route/UI behavior, while clearly documenting that the server is authoritative.
- Implement all relevant loading, empty, error, validation, success, and forbidden states.
- Never invent a backend endpoint. Mark assumptions `MOCKED` or `BLOCKED`.
- Do not expose creator personal or payment information in logs, analytics, fixtures intended for production, or screenshots.

## Per-task workflow

1. Restate the current phase goal and inspect affected code.
2. Identify assumptions, existing changes, and API readiness.
3. Implement the smallest coherent vertical slice.
4. Run focused tests, then the phase gates.
5. Visually check the affected responsive states.
6. Update the phase checklist and write/update `phases/HANDOFF.md`.
7. Stop at the phase boundary and report whether it is safe to proceed.

## Response contract

Every completion report must include:

- Outcome
- Files changed
- Verification performed
- Visual/responsive states checked
- API readiness tags
- Known limitations
- Next phase recommendation

