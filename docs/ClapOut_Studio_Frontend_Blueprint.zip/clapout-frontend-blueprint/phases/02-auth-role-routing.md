# Phase 2 - Authentication and Role Routing

## Goal

Create the entry flow and guarantee that each role reaches only its intended workspace.

## Scope

- Sign-in page matching the PDF's visual direction.
- Auth provider adapter, session bootstrap, sign-out, and forgot-password handoff.
- `authGuard`, `roleGuard`, forbidden page, not-found state, and return URL handling.
- Role-derived navigation and default-dashboard redirect.
- Session-expiry behavior and HTTP error mapping.

## Critical tests

- Admin, brand, and creator land on their own dashboards.
- Direct navigation to another role's URL produces `403` behavior.
- Unknown session does not flash protected content or the sign-in page.
- Sign-out clears private view state.

## Exit gate

- [ ] Critical tests pass
- [ ] Auth/API assumptions are tagged
- [ ] No authorization decision relies only on hidden navigation
- [ ] `HANDOFF.md` recommends proceed or hold

