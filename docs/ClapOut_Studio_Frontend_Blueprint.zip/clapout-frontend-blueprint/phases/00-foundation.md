# Phase 0 - Repository Foundation

## Goal

Create a production-ready Angular workspace and enforce architectural boundaries before feature work.

## Scope

- Scaffold the current stable Angular version with standalone routing, strict TypeScript, SCSS disabled unless required, and the selected package manager.
- Install the matching PrimeNG major, PrimeIcons, Tailwind CSS v4, `tailwindcss-primeui`, Chart.js, and date-fns.
- Configure PrimeNG styled mode with a custom ClapOut preset.
- Create `core`, `shared`, and `features` boundaries.
- Add environment configuration and an API base URL token without secrets.
- Configure ESLint, Prettier, Vitest, and Playwright.
- Establish CI commands and initial bundle budgets.
- Add a mock-adapter environment switch.

## Deliverables

- Application builds and renders a placeholder shell.
- Tests and Playwright smoke test run.
- Tailwind and PrimeNG semantic colors render from the same tokens.
- `README` contains install, run, test, and build commands.

## Exit gate

- [ ] Frozen-lockfile install succeeds
- [ ] Lint succeeds
- [ ] Production build succeeds
- [ ] Unit smoke test succeeds
- [ ] Playwright smoke test succeeds
- [ ] No raw secrets or production personal data exist
- [ ] `phases/HANDOFF.md` records version choices and commands

