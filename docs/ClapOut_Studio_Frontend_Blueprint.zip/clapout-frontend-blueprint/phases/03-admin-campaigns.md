# Phase 3 - Admin Dashboard and Campaign Operations

## Goal

Deliver the admin's primary campaign workflow from overview through publication.

## Scope

- Admin dashboard metrics, registration activity, attention queue, and recent campaigns.
- Campaign list, search, status filters, pagination, empty/error states.
- Campaign detail for each lifecycle state.
- Multi-step builder: artwork/basics, details, platform, budget/rate, timeline, requirements/resources, brand, preview.
- Draft persistence, dirty-form guard, validation summary, and image/file upload states.
- Submit, request changes, approve, publish, pause, close, edit, and duplicate UI according to permission/status rules.

## Key decisions

- A brand is required before publish and may be selected at draft creation.
- Use “Save draft” and “Publish”; correct PDF copy defects.
- Publication is a command with a confirmation and a recoverable error state.

## Exit gate

- [ ] Admin campaign happy path passes in Playwright
- [ ] Invalid status transitions are absent/disabled with explanation
- [ ] Wizard data survives permitted navigation/refresh behavior
- [ ] Mobile and desktop campaign layouts are checked
- [ ] API readiness is recorded per action

