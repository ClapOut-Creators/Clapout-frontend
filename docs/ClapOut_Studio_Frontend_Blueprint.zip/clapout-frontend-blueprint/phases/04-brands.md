# Phase 4 - Brand Management and Brand Workspace

## Goal

Make brands first-class records and enable controlled brand self-service.

## Scope

- Admin brand metrics and directory with server-oriented search/filter/pagination.
- Add-brand flow: identity, logo, website/social link, industry, location, primary contact, and account manager.
- Brand detail header, operational metrics, campaigns, recent registrations, contacts, and activity.
- Create campaign from brand detail with brand preselected.
- Brand-user dashboard, own campaigns, submission for review, read-only results, profile, and settings.
- Active, onboarding, inactive, suspended, and archived visual states.

## Data rules

- Brand record exists independently of a brand user's login.
- Suspending a brand does not silently unpublish campaigns.
- Brand user access is always scoped by `brandId` server-side and reflected in the frontend.

## Exit gate

- [ ] Admin can add and open a brand
- [ ] Campaign created from brand detail carries the correct brand
- [ ] Brand user cannot view another brand by URL manipulation
- [ ] Metrics use unambiguous labels
- [ ] Handoff records mocked/integrated endpoints

