# Phase 7 - Integration Hardening and MVP Release

## Goal

Replace remaining approved mocks, stabilize the full system, and produce a release candidate.

## Scope

- Integrate confirmed HTTP repositories and remove obsolete mock paths.
- Validate DTO mapping, pagination, filters, uploads, auth errors, and status commands.
- Add audit/analytics hooks defined in the quality contract.
- Perform accessibility, performance, responsive, privacy, and cross-browser testing.
- Verify production configuration and remove development-only routes/tools.
- Complete release notes, known limitations, and operational runbook.

## Release gate

- [ ] All critical E2E scenarios pass against the release environment
- [ ] No `BLOCKED` capability is mislabeled as complete
- [ ] Accessibility review has no critical issues
- [ ] Bundle budgets pass
- [ ] Error monitoring and analytics configuration are verified
- [ ] No secrets or real personal/payment data exist in source or fixtures
- [ ] Product owner approves campaign and registration workflows
- [ ] `HANDOFF.md` is converted into release notes and open backlog

