# Phase 1 - Design System and Application Shell

## Goal

Translate the PDF's visual language into reusable, responsive components before building feature pages.

## Scope

- Implement design tokens and PrimeNG preset.
- Build desktop sidebar, mobile drawer, creator mobile navigation, top bar, breadcrumbs, and page header.
- Build shared metric, status, empty, error, skeleton, filter, table shell, campaign card, dialog, and form components.
- Create a component showcase route available only in development.
- Verify keyboard focus, contrast, reduced motion, and overlay behavior.

## Exit gate

- [ ] All shared components show required states
- [ ] Shell works at mobile, tablet, laptop, and wide desktop widths
- [ ] Focus and overlay restoration are verified
- [ ] No feature-specific API calls exist in shared UI
- [ ] Visual review is recorded in `HANDOFF.md`

