# Phase 6 - Creator Experience

## Goal

Give creators a clear mobile-first path from opportunity discovery to completed content submission.

## Scope

- Creator dashboard with next action, deadlines, active participation, application decisions, and recommendations.
- Campaign discovery and filters.
- Public/creator campaign detail with eligibility messaging.
- Registration form, review, submission success, and duplicate-registration handling.
- Applications list and status timeline.
- Accepted-campaign workspace with brief, resources, deadline, and content-link submission.
- Profile completion, social profiles, portfolio, payout details, and settings.
- Informational earnings summary without pretending a payout has executed.

## Exit gate

- [ ] Creator apply-and-track E2E passes
- [ ] Duplicate application is gracefully explained
- [ ] Rejected/waitlisted/accepted states state the next action
- [ ] Content link validation and retry work
- [ ] Mobile navigation and small-screen forms pass review

