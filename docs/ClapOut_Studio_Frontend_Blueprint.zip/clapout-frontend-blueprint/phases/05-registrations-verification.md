# Phase 5 - Registrations, Decisions, and Verification

## Goal

Deliver the most operationally important admin workspace: inspecting and deciding creator registrations.

## Scope

- Global registrations page and campaign-scoped registration tab.
- Search/filter/sort/pagination with URL state.
- Registration detail page or large workspace panel with creator profile, social accounts, answers, portfolio, payment summary, notes, and status history.
- Shortlist, waitlist, accept, reject, and restore-to-review commands with confirmation/reason rules.
- Manual view verification form and calculated amount preview.
- CSV export trigger with progress, completion, and failure feedback.
- Personally identifiable information masking where full data is not required.

## Calculation rule

The frontend may preview `verifiedViews / rateUnitViews * rate`, but the server response is authoritative for payable amounts.

## Exit gate

- [ ] Admin registration-decision E2E passes
- [ ] Status history refreshes after a decision
- [ ] Calculation rounding/currency tests pass
- [ ] Permission and privacy review passes
- [ ] Tables are usable at supported widths

